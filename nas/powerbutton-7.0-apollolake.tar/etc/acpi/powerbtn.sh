#!/bin/sh

syno_poweroff_task -r
poweroff

