# netflix-proxy [![layers](https://images.microbadger.com/badges/image/ab77/sniproxy.svg)](https://microbadger.com/images/ab77/sniproxy "Get your own image badge on microbadger.com")
Docker packaged smart DNS proxy to watch Netflix out of region using BIND and sniproxy.

# Instructions
See, https://github.com/ab77/netflix-proxy

[![ab1](https://avatars2.githubusercontent.com/u/2033996?v=3&s=96)](http://ab77.github.io/)
